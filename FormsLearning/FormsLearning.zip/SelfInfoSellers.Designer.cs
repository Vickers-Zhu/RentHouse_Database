﻿namespace FormsLearning
{
    partial class SelfInfoSellers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SelfInfoSellers));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Nmlabel = new System.Windows.Forms.Label();
            this.CinfoDisplay = new System.Windows.Forms.LinkLabel();
            this.CaddrDisplay = new System.Windows.Forms.LinkLabel();
            this.CjopDisplay = new System.Windows.Forms.LinkLabel();
            this.CstudyDisplay = new System.Windows.Forms.LinkLabel();
            this.DtelDisplay = new System.Windows.Forms.LinkLabel();
            this.LsexDisplay = new System.Windows.Forms.LinkLabel();
            this.CaddrLabel = new System.Windows.Forms.Label();
            this.CjobLabel = new System.Windows.Forms.Label();
            this.CinfoLabel = new System.Windows.Forms.Label();
            this.CstudyLabel = new System.Windows.Forms.Label();
            this.DtelLabel = new System.Windows.Forms.Label();
            this.LsexLabel = new System.Windows.Forms.Label();
            this.LnoDisplay = new System.Windows.Forms.Label();
            this.CnoLabel = new System.Windows.Forms.Label();
            this.NameLabel = new System.Windows.Forms.LinkLabel();
            this.LhmtnLabel = new System.Windows.Forms.Label();
            this.LhmtnDisplay = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(22, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(106, 83);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Nmlabel
            // 
            this.Nmlabel.AutoSize = true;
            this.Nmlabel.BackColor = System.Drawing.SystemColors.Control;
            this.Nmlabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Nmlabel.Location = new System.Drawing.Point(149, 58);
            this.Nmlabel.Name = "Nmlabel";
            this.Nmlabel.Size = new System.Drawing.Size(69, 25);
            this.Nmlabel.TabIndex = 2;
            this.Nmlabel.Text = "姓名：";
            // 
            // CinfoDisplay
            // 
            this.CinfoDisplay.AutoSize = true;
            this.CinfoDisplay.Location = new System.Drawing.Point(88, 465);
            this.CinfoDisplay.Name = "CinfoDisplay";
            this.CinfoDisplay.Size = new System.Drawing.Size(70, 15);
            this.CinfoDisplay.TabIndex = 21;
            this.CinfoDisplay.TabStop = true;
            this.CinfoDisplay.Text = "Oh♂Yeah";
            this.CinfoDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CinfoDisplay_LinkClicked);
            // 
            // CaddrDisplay
            // 
            this.CaddrDisplay.AutoSize = true;
            this.CaddrDisplay.Location = new System.Drawing.Point(88, 395);
            this.CaddrDisplay.Name = "CaddrDisplay";
            this.CaddrDisplay.Size = new System.Drawing.Size(125, 15);
            this.CaddrDisplay.TabIndex = 20;
            this.CaddrDisplay.TabStop = true;
            this.CaddrDisplay.Text = "€8CWP0CXaKx3€";
            this.CaddrDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CaddrDisplay_LinkClicked);
            // 
            // CjopDisplay
            // 
            this.CjopDisplay.AutoSize = true;
            this.CjopDisplay.Location = new System.Drawing.Point(222, 249);
            this.CjopDisplay.Name = "CjopDisplay";
            this.CjopDisplay.Size = new System.Drawing.Size(37, 15);
            this.CjopDisplay.TabIndex = 19;
            this.CjopDisplay.TabStop = true;
            this.CjopDisplay.Text = "跤警";
            this.CjopDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CjopDisplay_LinkClicked);
            // 
            // CstudyDisplay
            // 
            this.CstudyDisplay.AutoSize = true;
            this.CstudyDisplay.Location = new System.Drawing.Point(88, 249);
            this.CstudyDisplay.Name = "CstudyDisplay";
            this.CstudyDisplay.Size = new System.Drawing.Size(67, 15);
            this.CstudyDisplay.TabIndex = 18;
            this.CstudyDisplay.TabStop = true;
            this.CstudyDisplay.Text = "研究♀生";
            this.CstudyDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.CstudyDisplay_LinkClicked);
            // 
            // DtelDisplay
            // 
            this.DtelDisplay.AutoSize = true;
            this.DtelDisplay.Location = new System.Drawing.Point(222, 151);
            this.DtelDisplay.Name = "DtelDisplay";
            this.DtelDisplay.Size = new System.Drawing.Size(95, 15);
            this.DtelDisplay.TabIndex = 17;
            this.DtelDisplay.TabStop = true;
            this.DtelDisplay.Text = "18406587523";
            this.DtelDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DtelDisplay_LinkClicked);
            // 
            // LsexDisplay
            // 
            this.LsexDisplay.AutoSize = true;
            this.LsexDisplay.Location = new System.Drawing.Point(88, 151);
            this.LsexDisplay.Name = "LsexDisplay";
            this.LsexDisplay.Size = new System.Drawing.Size(22, 15);
            this.LsexDisplay.TabIndex = 16;
            this.LsexDisplay.TabStop = true;
            this.LsexDisplay.Text = "♂";
            this.LsexDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LsexDisplay_LinkClicked);
            // 
            // CaddrLabel
            // 
            this.CaddrLabel.AutoSize = true;
            this.CaddrLabel.BackColor = System.Drawing.SystemColors.Control;
            this.CaddrLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CaddrLabel.Location = new System.Drawing.Point(26, 389);
            this.CaddrLabel.Name = "CaddrLabel";
            this.CaddrLabel.Size = new System.Drawing.Size(69, 25);
            this.CaddrLabel.TabIndex = 10;
            this.CaddrLabel.Text = "地址：";
            // 
            // CjobLabel
            // 
            this.CjobLabel.AutoSize = true;
            this.CjobLabel.BackColor = System.Drawing.SystemColors.Control;
            this.CjobLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CjobLabel.Location = new System.Drawing.Point(160, 243);
            this.CjobLabel.Name = "CjobLabel";
            this.CjobLabel.Size = new System.Drawing.Size(69, 25);
            this.CjobLabel.TabIndex = 11;
            this.CjobLabel.Text = "工作：";
            // 
            // CinfoLabel
            // 
            this.CinfoLabel.AutoSize = true;
            this.CinfoLabel.BackColor = System.Drawing.SystemColors.Control;
            this.CinfoLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CinfoLabel.Location = new System.Drawing.Point(26, 459);
            this.CinfoLabel.Name = "CinfoLabel";
            this.CinfoLabel.Size = new System.Drawing.Size(69, 25);
            this.CinfoLabel.TabIndex = 12;
            this.CinfoLabel.Text = "备注：";
            // 
            // CstudyLabel
            // 
            this.CstudyLabel.AutoSize = true;
            this.CstudyLabel.BackColor = System.Drawing.SystemColors.Control;
            this.CstudyLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CstudyLabel.Location = new System.Drawing.Point(26, 243);
            this.CstudyLabel.Name = "CstudyLabel";
            this.CstudyLabel.Size = new System.Drawing.Size(69, 25);
            this.CstudyLabel.TabIndex = 13;
            this.CstudyLabel.Text = "学历：";
            // 
            // DtelLabel
            // 
            this.DtelLabel.AutoSize = true;
            this.DtelLabel.BackColor = System.Drawing.SystemColors.Control;
            this.DtelLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DtelLabel.Location = new System.Drawing.Point(160, 145);
            this.DtelLabel.Name = "DtelLabel";
            this.DtelLabel.Size = new System.Drawing.Size(50, 25);
            this.DtelLabel.TabIndex = 14;
            this.DtelLabel.Text = "电话";
            // 
            // LsexLabel
            // 
            this.LsexLabel.AutoSize = true;
            this.LsexLabel.BackColor = System.Drawing.SystemColors.Control;
            this.LsexLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LsexLabel.Location = new System.Drawing.Point(26, 145);
            this.LsexLabel.Name = "LsexLabel";
            this.LsexLabel.Size = new System.Drawing.Size(69, 25);
            this.LsexLabel.TabIndex = 15;
            this.LsexLabel.Text = "性别：";
            // 
            // LnoDisplay
            // 
            this.LnoDisplay.AutoSize = true;
            this.LnoDisplay.ForeColor = System.Drawing.Color.Red;
            this.LnoDisplay.Location = new System.Drawing.Point(211, 98);
            this.LnoDisplay.Name = "LnoDisplay";
            this.LnoDisplay.Size = new System.Drawing.Size(87, 15);
            this.LnoDisplay.TabIndex = 23;
            this.LnoDisplay.Text = "1251fwq651";
            // 
            // CnoLabel
            // 
            this.CnoLabel.AutoSize = true;
            this.CnoLabel.BackColor = System.Drawing.SystemColors.Control;
            this.CnoLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CnoLabel.Location = new System.Drawing.Point(149, 92);
            this.CnoLabel.Name = "CnoLabel";
            this.CnoLabel.Size = new System.Drawing.Size(69, 25);
            this.CnoLabel.TabIndex = 22;
            this.CnoLabel.Text = "番号：";
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.LinkColor = System.Drawing.Color.Navy;
            this.NameLabel.Location = new System.Drawing.Point(211, 64);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(52, 15);
            this.NameLabel.TabIndex = 24;
            this.NameLabel.TabStop = true;
            this.NameLabel.Text = "李田所";
            this.NameLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.NameLabel_LinkClicked);
            // 
            // LhmtnLabel
            // 
            this.LhmtnLabel.AutoSize = true;
            this.LhmtnLabel.BackColor = System.Drawing.SystemColors.Control;
            this.LhmtnLabel.Font = new System.Drawing.Font("Microsoft YaHei", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.LhmtnLabel.Location = new System.Drawing.Point(26, 312);
            this.LhmtnLabel.Name = "LhmtnLabel";
            this.LhmtnLabel.Size = new System.Drawing.Size(69, 25);
            this.LhmtnLabel.TabIndex = 13;
            this.LhmtnLabel.Text = "故乡：";
            // 
            // LhmtnDisplay
            // 
            this.LhmtnDisplay.AutoSize = true;
            this.LhmtnDisplay.Location = new System.Drawing.Point(88, 318);
            this.LhmtnDisplay.Name = "LhmtnDisplay";
            this.LhmtnDisplay.Size = new System.Drawing.Size(38, 15);
            this.LhmtnDisplay.TabIndex = 25;
            this.LhmtnDisplay.TabStop = true;
            this.LhmtnDisplay.Text = "**乡";
            this.LhmtnDisplay.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LhmtnDisplay_LinkClicked);
            // 
            // SelfInfoSellers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 593);
            this.Controls.Add(this.LhmtnDisplay);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.LnoDisplay);
            this.Controls.Add(this.CnoLabel);
            this.Controls.Add(this.CinfoDisplay);
            this.Controls.Add(this.CaddrDisplay);
            this.Controls.Add(this.CjopDisplay);
            this.Controls.Add(this.CstudyDisplay);
            this.Controls.Add(this.DtelDisplay);
            this.Controls.Add(this.LsexDisplay);
            this.Controls.Add(this.CaddrLabel);
            this.Controls.Add(this.CjobLabel);
            this.Controls.Add(this.CinfoLabel);
            this.Controls.Add(this.LhmtnLabel);
            this.Controls.Add(this.CstudyLabel);
            this.Controls.Add(this.DtelLabel);
            this.Controls.Add(this.LsexLabel);
            this.Controls.Add(this.Nmlabel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "SelfInfoSellers";
            this.Text = "SellersInfoInterface";
            this.Load += new System.EventHandler(this.SelfInfoSellers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Nmlabel;
        private System.Windows.Forms.LinkLabel CinfoDisplay;
        private System.Windows.Forms.LinkLabel CaddrDisplay;
        private System.Windows.Forms.LinkLabel CjopDisplay;
        private System.Windows.Forms.LinkLabel CstudyDisplay;
        private System.Windows.Forms.LinkLabel DtelDisplay;
        private System.Windows.Forms.LinkLabel LsexDisplay;
        private System.Windows.Forms.Label CaddrLabel;
        private System.Windows.Forms.Label CjobLabel;
        private System.Windows.Forms.Label CinfoLabel;
        private System.Windows.Forms.Label CstudyLabel;
        private System.Windows.Forms.Label DtelLabel;
        private System.Windows.Forms.Label LsexLabel;
        private System.Windows.Forms.Label LnoDisplay;
        private System.Windows.Forms.Label CnoLabel;
        private System.Windows.Forms.LinkLabel NameLabel;
        private System.Windows.Forms.Label LhmtnLabel;
        private System.Windows.Forms.LinkLabel LhmtnDisplay;
    }
}